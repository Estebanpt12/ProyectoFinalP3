package co.edu.uniquindio.casasubastas.exceptions;

public class SoldProductException extends Exception{
    public SoldProductException (String message){
        super(message);
    }
}
