package co.edu.uniquindio.casasubastas.exceptions;

public class InsufficientBidException extends Exception{
    public InsufficientBidException(String message){
        super(message);
    }
}
