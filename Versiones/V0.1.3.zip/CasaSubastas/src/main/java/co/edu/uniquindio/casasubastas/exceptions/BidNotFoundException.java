package co.edu.uniquindio.casasubastas.exceptions;

public class BidNotFoundException extends Exception{

    public BidNotFoundException(String message){
        super(message);
    }
}
