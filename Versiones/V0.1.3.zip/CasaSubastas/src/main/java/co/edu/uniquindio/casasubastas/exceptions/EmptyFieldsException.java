package co.edu.uniquindio.casasubastas.exceptions;

public class EmptyFieldsException extends Exception{
    public EmptyFieldsException(String message){
        super(message);
    }
}
