package co.edu.uniquindio.casasubastas.exceptions;

public class UserNotLoggedException extends Exception{
    public UserNotLoggedException(String message){
        super(message);
    }
}
