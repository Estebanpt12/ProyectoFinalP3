package co.edu.uniquindio.casasubastas.exceptions;

public class ProductsLimitException extends Exception{
    public ProductsLimitException(String message){
        super(message);
    }
}
