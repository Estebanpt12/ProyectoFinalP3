package co.edu.uniquindio.casasubastas.exceptions;

public class ProductTimeException extends Exception{
    public ProductTimeException(String message){
        super(message);
    }
}
