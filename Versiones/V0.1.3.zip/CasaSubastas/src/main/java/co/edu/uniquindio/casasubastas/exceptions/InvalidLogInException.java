package co.edu.uniquindio.casasubastas.exceptions;

public class InvalidLogInException extends Exception{
    public  InvalidLogInException(String message){
        super(message);
    }
}
